package com.example.ezyfood3.storage;

import com.example.ezyfood3.models.Balance;

import java.util.ArrayList;

public class ListBalance {
    public static ArrayList<Balance> listBalance = new ArrayList<>();
}
